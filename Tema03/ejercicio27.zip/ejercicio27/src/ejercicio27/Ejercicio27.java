package ejercicio27;

import java.util.Scanner;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio27 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int n1, n2, opt = 0, op;
        System.out.println("Introduzca un número");
        n1 = entrada.nextInt();
        System.out.println("Introduzca otro número");
        n2 = entrada.nextInt();
        do {
            System.out.println(" || * || Introduzca que desea hacer ");
            System.out.println(" || 1 || Sumar los números");
            System.out.println(" || 2 || Restar los números");
            System.out.println(" || 3 || Multiplicar los números");
            System.out.println(" || 4 || Dividir los números");
            System.out.println(" || 5 || Salir del programa");
            System.out.println(" || * || ALBERTO REY MORENO - 2016 ");
            
            opt = entrada.nextInt();
            if (opt == 1) {
                op = n1 + n2;
                System.out.println(op);
            }
            if (opt == 2) {
                op = n1 - n2;
                System.out.println(op);
            }
            if (opt == 3) {
                op = n1 * n2;
                System.out.println(op);
            }
            if (opt == 4) {
                try {
                    op = n1 / n2;
                    System.out.println(op);
                } catch (Exception e) {
                    e.printStackTrace(System.out);
                    op = 0;
                    System.out.println("Error: ");

                }

                System.out.println(op);
            }
        } while (opt != 5);

    }

}
