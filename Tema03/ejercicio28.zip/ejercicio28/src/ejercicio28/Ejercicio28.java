package ejercicio28;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio28 {

    public static void main(String[] args) {

        double aleatorio = Math.floor((Math.random() * 100)) + 1; //GENERACION DE UN NUMERO ALEATORIO

        int aleatorioent = (int) aleatorio; //CAMBIAMOS DE DOUBLE A INTEGER

        System.out.println(aleatorioent);

    }

}
