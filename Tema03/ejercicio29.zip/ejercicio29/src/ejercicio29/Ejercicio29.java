package ejercicio29;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio29 {

    public static void main(String[] args) {
        
        int num;
        Scanner entrada = new Scanner(System.in);
        double aleatorio=Math.floor((Math.random()*100))+1;
        int aleatorioent = (int) aleatorio;
        do{
        System.out.println("Introduce un número");
        num=entrada.nextInt();
        if(num<aleatorioent){
            System.out.println("¡Mayor!");
        }
        if(num>aleatorio){
            System.out.println("¡Menor!");
        }
            }while(num!=aleatorioent);
        System.out.println("¡Correcto, has acertado!");
        
    }
    
}
