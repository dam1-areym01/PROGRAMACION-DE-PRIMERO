package ejercicio21;

import java.util.Scanner;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        int dividendo, divisor, resultado;
        
        System.out.println("Introduce el Dividendo");
        dividendo = entrada.nextInt();
        
        System.out.println("Introduce el divisor");
        divisor = entrada.nextInt();

        try {

            resultado = dividendo / divisor;
            System.out.println("El resultado de la división es " + resultado);
        } catch (Exception e) {
            resultado = 0;
            System.out.println("Error.");

        }

    }
}
