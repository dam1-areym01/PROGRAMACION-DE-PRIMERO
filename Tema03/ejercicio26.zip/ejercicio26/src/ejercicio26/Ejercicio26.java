package ejercicio26;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio26 {

    public static void main(String[] args) {

        int res = 0;
        String suma = "";
        for (int i = 111; i < 222; i = i + 2) {
            suma = suma + " " + i;
            res = res + i;
        }

        System.out.println(suma);

        System.out.println(res);

    }

}
