package ejercicio24;

import java.util.Scanner;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio24 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int num, res = 0, cont = 0, mul = 0;

        //COntrolo el bucle del que número sea mayor a 0
        do {

            System.out.println("Introduzca un número");
            num = entrada.nextInt();
            while (res < num) {
                mul++;
                res = mul * 3;
                System.out.println(res);
                cont++;
            }
        } while (num < 0);
        System.out.println(cont);
    }

}
