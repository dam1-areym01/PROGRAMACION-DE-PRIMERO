package ejercicio30;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio30 {

    public static void main(String[] args) {
        
        int num = 0, cont = 1;
        
        double aleatorio = Math.floor((Math.random() * 100)) + 1;
        int aleatorioent = (int) aleatorio;
        boolean letra;
        

        do {            
            System.out.println(" || Introduce un número entre 1 y 100 || ");
            
            do{
                try{
                    Scanner entrada = new Scanner(System.in);
                    num = entrada.nextInt();
                    letra=false;
                }catch(InputMismatchException e){
                    System.out.println("¡ERROR! ¡INTRODUCE UN NÚMERO!");
                    letra=true;
                }
                
            }while(letra==true);
            
            
            if (num < aleatorioent) {
                System.out.println("¡Mayor!");
            }
            if (num > aleatorio) {
                System.out.println("¡Menor!");
            }

            cont++;

        } while (num != aleatorioent);
        
        System.out.println("¡Correcto, has acertado!");
        
        System.out.println("¡Has necesitado " + cont + " intentos para acertar!");
        
    }
    
}
