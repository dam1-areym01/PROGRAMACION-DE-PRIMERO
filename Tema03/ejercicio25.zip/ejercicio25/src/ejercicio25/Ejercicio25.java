package ejercicio25;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio25 {

    public static void main(String[] args) {

        int num = 17, suma = 0;
        do {
            if (num % 2 == 0) {
                suma = suma + num;
            }
            num++;
        } while (num < 139);
        System.out.println(suma);
    }

}
