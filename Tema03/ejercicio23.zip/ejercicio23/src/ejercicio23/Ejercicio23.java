package ejercicio23;

import java.util.Scanner;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio23 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int num, cont = 0;
        do {
            System.out.println("Introduce un número");
            num = entrada.nextInt();
            while (cont < num) {

                cont++;
                System.out.println(cont);
            }

        } while (num < 1);

    }

}
