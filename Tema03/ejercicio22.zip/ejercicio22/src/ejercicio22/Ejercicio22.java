package ejercicio22;

import java.util.Scanner;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio22 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int num, num2, suma;
        try {
            System.out.println("Introduzca un número");

            num = entrada.nextInt();

            System.out.println("Introduzca otro número");

            num2 = entrada.nextInt();
            suma = num + num2;
        } catch (java.util.InputMismatchException e) {

            System.out.println("Error");
            suma = 0;
        }
        System.out.println("El resultado de tu suma es " + suma);
    }
}
