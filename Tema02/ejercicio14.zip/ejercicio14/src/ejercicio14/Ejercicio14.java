/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio14;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio14 {

    public static void main(String[] args) {
        
        double radio = 5.2, resultado;
        final double PI=3.141592;
        resultado=PI*(radio*radio);
        System.out.println(" El area de la circunferencia cuyo radio vale " + radio + " cm es " + resultado + " cm.");
        
    }
    
}
