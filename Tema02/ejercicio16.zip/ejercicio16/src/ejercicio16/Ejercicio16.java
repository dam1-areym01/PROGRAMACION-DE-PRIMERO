package ejercicio16;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio16 {

    public static void main(String[] args) {

        int dinero = 80;
        int billete50, billete10;
        
        int d50 = 50, d10 = 10;
       
        billete50=dinero/d50;
        billete10=(dinero%d50)/d10;
        System.out.println(dinero + " euros hacen un total de: " + billete50 + " billetes de 50 € y " + billete10 + 
                " billetes de 10 €.");
        
    }
    
}
