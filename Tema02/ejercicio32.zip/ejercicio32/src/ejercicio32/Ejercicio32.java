package ejercicio32;
import java.util.Scanner; 
/**
 *
 * @author ALBERTO REY MORENO x8
 */
public class Ejercicio32 {

    public static void main(String[] args) {
       
        Scanner entrada = new Scanner (System.in);
        
        int dinero, billete50, billete20, billete10, billete5, moneda2, moneda1;
        System.out.println("Por favor, indique una cantidad de dinero en €uros: ");
        dinero = entrada.nextInt();
        billete50 = dinero/50;
        billete20 = dinero%50/20;
        billete10 = dinero%50%20/10;
        billete5 = dinero%50%20%10/5;
        moneda2 = dinero%50%20%10%5/2;
        moneda1 = dinero%50%20%10%5%2;
        System.out.println("" + dinero + " Euros se descomponen en " + billete50 + " billetes de 50 €, " + billete20 + " billetes de 20 €, " + billete10 + " billetes de 10 €, " + billete5 + " billetes de 5 €, " + moneda2 + " monedas de 2 € y " + moneda1 + " monedas de 1 €. ");
        
        
    }
    
}
