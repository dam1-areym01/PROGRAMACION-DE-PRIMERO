package ejercicio26;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio26 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        int num, unidades, decenas, centenas, millares;
        
        System.out.println("Por favor, introduzca un número de 4 cifras: ");
        num = entrada.nextInt();
        
        millares = num/1000;
        centenas = num%1000/100;
        decenas = (num%1000)%100/10;
        unidades = num%1000%100%10/1;
        
        
        System.out.println("La primera cifra es: " + millares);
        System.out.println("La segunda cifra es: " + centenas);
        System.out.println("La tercera cifra es: " + decenas);
        System.out.println("La cuarta cifra es: " + unidades);       
        
    }
    
}
