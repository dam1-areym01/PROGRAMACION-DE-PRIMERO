package ejercicio30;
/**
 *
 * @author ALBERTO REY MORENO x8
 */
public class Ejercicio30 {

    public static void main(String[] args) {
        int numero;
        char letraA, letraB, letraC, letraa, letrab, letrac, num0, num1, num2, simdol, simsum, simprod, simraya;
        
        letraA = 'A';
        letraB = 'B';
        letraC = 'C';
        num0 = '0';
        num1 = '1';
        num2 = '2';
        simdol = '$';
        simsum = '+';
        simprod = '*';
        simraya = '/';
        
        numero = (int) letraA;
        System.out.println("El código ASCII de " + letraA + " es " + numero);
        
        numero = (int) letraB;
        System.out.println("El código ASCII de " + letraB + " es " + numero);
        
        numero = (int) letraC;
        System.out.println("El código ASCII de " + letraC + " es " + numero);
        
        numero = (int) num0;
        System.out.println("El código ASCII de " + num0 + " es " + numero);
        
        numero = (int) num1;
        System.out.println("El código ASCII de " + num1 + " es " + numero);
        
        numero = (int) num2;
        System.out.println("El código ASCII de " + num2 + " es " + numero);
        
        numero = (int) simdol;
        System.out.println("El código ASCII de " + simdol + " es " + numero);
        
        numero = (int) simsum;
        System.out.println("El código ASCII de " + simsum + " es " + numero);
        
        numero = (int) simprod;
        System.out.println("El código ASCII de " + simprod + " es " + numero);
        
        numero = (int) simraya;
        System.out.println("El código ASCII de " + simraya + " es " + numero);
    }
    
}
