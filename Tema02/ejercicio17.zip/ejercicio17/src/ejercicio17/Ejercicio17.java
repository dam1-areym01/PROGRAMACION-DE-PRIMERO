package ejercicio17;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio17 {

    public static void main(String[] args) {

        int w, x, y, z;
        
        w=25+20-15;
        System.out.println("A) 25+20-15 = " + w);
        
        x=20*10+15*10;
        System.out.println("B) 20*10+15*10 = " + x);
        
        y=20*10/2-20/5*3;
        System.out.println("C) 20*10/2-20/5*3 = " + y);
        
        z=15/10*2+3/4*8;
        System.out.println("D) 15/10*2+3/4*8 = " + z);
        
    }
    
}
