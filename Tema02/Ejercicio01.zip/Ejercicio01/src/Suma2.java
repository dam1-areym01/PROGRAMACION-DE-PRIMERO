/**
 *
 * @author Alberto Rey Moreno
 */

public class Suma2 {

    public static void main(String[] args) {
        
        //DECLARAMOS VARIABLES
        
            int numero1=30; 
            int numero2, resultado;
        
        //DECLARAMOS CONSTANTES
            
            numero2=700;
            
        //PROGRAMA
            
        resultado=numero1+numero2;
        System.out.println("El resultado de la suma es: " +resultado);
        
    }
    
}
