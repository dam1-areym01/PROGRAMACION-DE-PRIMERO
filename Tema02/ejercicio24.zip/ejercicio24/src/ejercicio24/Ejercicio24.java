package ejercicio24;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio24 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        float ssinf, bbdd, pgrmc, entdl, lmsgi, fol, media;
        
        System.out.println("Por favor, introduzca la nota de Sistemas Informáticos: ");
        ssinf = entrada.nextFloat();
        
        System.out.println("Por favor, introduzca la nota de Base de Datos: ");
        bbdd = entrada.nextFloat();
        
        System.out.println("Por favor, introduzca la nota de Programación: ");
        pgrmc = entrada.nextFloat();
        
        System.out.println("Por favor, introduzca la nota de Entornos de Desarrollo: ");
        entdl = entrada.nextFloat();
        
        System.out.println("Por favor, introduzca la nota de Lenguajes de Marcas: ");
        lmsgi = entrada.nextFloat();
        
        System.out.println("Por favor, introduzca la nota de Formación y Orientación Laboral:" );
        fol = entrada.nextFloat();
        
        media = (ssinf+bbdd+pgrmc+entdl+lmsgi+fol)/6;
        System.out.println("Su nota media del curso es: " + media);
        
        
    }
    
}
