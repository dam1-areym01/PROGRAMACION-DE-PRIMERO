package ejercicio11;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class cuadrado {

    public static void main(String[] args) {
        int numero = 2, cuad;

        cuad=numero*numero;
        System.out.println("EL NUMERO ES " + numero);
        System.out.println("EL CUADRADO DE " + numero + " ES: " + cuad);
        
    }
    
}