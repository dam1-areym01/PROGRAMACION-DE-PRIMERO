package ejercicio23;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio23 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        float precio, total;
        int cant;
        System.out.println("\t Por favor, introduzca el precio (en €uros) del modelo de ordenador que desea comprar:");
        precio = entrada.nextFloat();
        System.out.println("\t ¿Cuántas unidades desea llevarse?");
        cant = entrada.nextInt();
        total=precio*cant;
        System.out.println("El precio total de su compra es " + total + " €.");
        
    }
    
}
