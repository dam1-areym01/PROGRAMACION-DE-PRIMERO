package ejercicio19;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio19 {

    public static void main(String[] args) {
                
        
        int a=3, b=6, c;
        c=a/b;
        
        System.out.println("El valor de c es: " + c); // DIVISION NORMAL
        
        c=a%b;
        System.out.println("El valor de c es: " + c); // RESTO DE DIVISION
        
        a++;
        System.out.println("El valor de a es: " + a); // INCREMENTO DE a
        
        ++a;
        System.out.println("El valor de a es: " + a); // INCREMENTO DE a
        
        c=++a + b++;
        System.out.println("El valor de a es: " + a); // INCREMENTAMOS b, SUMAMOS a+b Y LUEGO VOLVEMOS A INCREMENTAR
        System.out.println("El valor de b es: " + b);
        System.out.println("El valor de c es: " + c);
        
        c=++a + b++;
        System.out.println("El valor de a es: " + a); // SUMAMOS a+b Y LUEGO INCREMENTAMOS
        System.out.println("El valor de b es: " + b);
        System.out.println("El valor de c es: " + c);
        
        
    }
    
}
