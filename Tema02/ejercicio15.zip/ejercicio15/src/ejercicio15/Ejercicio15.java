/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio15;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio15 {

    public static void main(String[] args) {

           int tiempo = 10000;
           int horas, cociente, min, seg;
           
           int vars = 3600, varm = 60; // VARIABLES CONTINUAS
           
           horas=tiempo/vars;
           cociente=tiempo%varm;
           min=cociente/varm;
           seg=cociente%varm;
           
           System.out.println(tiempo + " segundos hacen un total de " + horas + " horas " + min + " minutos " + seg + " segundos.");

    }
    
}
