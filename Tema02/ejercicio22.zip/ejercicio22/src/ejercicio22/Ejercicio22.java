package ejercicio22;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio22 {

    public static void main(String[] args) {
        
        double lado, area, perimetro;
        
        Scanner entrada = new Scanner (System.in);
        System.out.println ("\t Por favor, introduzca la medida de un lado en cm: ");
        
        lado = entrada.nextDouble();
        area=lado*lado*(lado*1.73205081);
        perimetro=lado+lado+lado;
        
        System.out.println("El área de un triangulo de lado " + lado + " cm es: " + area + " cm2.");
        System.out.println("El perimetro de un triangulo de lado " + lado + " cm es: " + perimetro + " cm.");
        
    }
    
}
