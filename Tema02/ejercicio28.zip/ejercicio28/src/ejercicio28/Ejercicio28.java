package ejercicio28;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO x8
 */
public class Ejercicio28 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        float archivo, adsl, tiempo;
        
        System.out.println("Por favor, introduzca el tamaño de archivo en MB: ");
        archivo = entrada.nextFloat();
        
        System.out.println("Por favor, introduzca la velocidad de descarga de su ADSL en mb: ");
        adsl = entrada.nextFloat();
        
        tiempo = ((archivo * 8)/adsl)/60;
        System.out.println("La descarga del archivo con tamaño: " + archivo + "MB, con una velocidad de " + adsl + " mb, en un tiempo de " + tiempo + " segundos.");
                    
    }
    
}
