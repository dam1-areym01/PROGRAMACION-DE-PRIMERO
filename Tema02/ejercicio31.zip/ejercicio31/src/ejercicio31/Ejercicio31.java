package ejercicio31;
/**
 *
 * @author ALBERTO REY MORENO x8
 */
public class Ejercicio31 {

    public static void main(String[] args) {
        System.out.println("*********     ***       *       *");
        System.out.println("*       *   *     *    ***     * *");
        System.out.println("*       *  *       *  *****   *   *");
        System.out.println("*       *  *       *    *    *     *");
        System.out.println("*       *  *       *    *   *       *");
        System.out.println("*       *  *       *    *    *     *");
        System.out.println("*       *  *       *    *     *   * ");
        System.out.println("*       *   *     *     *      * *");
        System.out.println("*********     ***       *       *");
    }
    
}
