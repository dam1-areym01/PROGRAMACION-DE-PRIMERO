/**
 *
 * @author ALBERTO REY MORENO
 */
public class notamedia {

    public static void main(String[] args) {
       
       //VARIABLES Y DATOS
        
       float examen1=4, examen2=9, resultado;
       
       //PROGRAMA
       
       resultado= (examen1 + examen2 )/2;
       System.out.println(" Tu nota media en PROGRAMACIÓN es " +resultado );
    }
    
}
