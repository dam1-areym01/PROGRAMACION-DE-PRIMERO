package ejercicio21;
import java.util.Scanner;
/**
 *
 * @author areym01
 */
public class Ejercicio21 {

    public static void main(String[] args) {
        
        int tiempo, dias, horas, minutos, segundos, restoh, restom;
        
        Scanner entrada = new Scanner (System.in);
        System.out.println ("\t Por favor, introduzca un número de segundos: ");
        
        tiempo = entrada.nextInt();
        
        dias=tiempo/86400;
        restoh=tiempo%86400;
        
        horas=restoh/3600;
        restom=restoh%3600;
        
        minutos=restom/60;
        segundos=restom%60;
        
        System.out.println("" + tiempo + " segundos hacen un total de " + dias + " días, " + horas + " horas, " + minutos + " minutos, " + segundos + " segundos.");
        
    }
    
}
