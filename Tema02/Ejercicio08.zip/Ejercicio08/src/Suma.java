/**
 *
 * @author ALBERTO REY MORENO
 */

public class Suma {

    public static void main(String[] args) {
        
        //VARIABLES
        
        int n1=50, n2=30;
        int suma=0;
        
        // PROGRAMA
        
        suma =n1+n2;
        System.out.println("LA SUMA ES: " + suma);
        // TODO code application logic here
    }
    
}
