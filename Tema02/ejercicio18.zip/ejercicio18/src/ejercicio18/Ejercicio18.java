package ejercicio18;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio18 {

    public static void main(String[] args) {
        
        int a = 2, b = 4;
        int x, y, z;
        
        x=-a+5%b-a*a;
        System.out.println("A) -a+5%b-a*a = " + x);
        y=5+3%7*b*a-b%a;
        System.out.println("B) 5+3%7*b*a-b%a = " + y);
        z=(a+1)*(b+1)-b/a;
        System.out.println("C) a+1)*(b+1)-b/a = " + z);
        
    }
    
}
