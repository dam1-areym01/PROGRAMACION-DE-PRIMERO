/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author areym01
 */
public class ejercicio09 {
    
    public static void main(String[] args) {
        
        //VARIABLE
        
        double radio=3.55, resultado;
        final double PI=3.141592;
        
        //PROGRAMA
        
        resultado=2*PI*radio;
        System.out.println("La longitud de la circunferencia cuyo radio vale " + radio + " metros es " + resultado + " metros.");
    
    }
    
}
