/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ALBERTO REY MORENO
 */
public class ejercicio13 {

    public static void main(String[] args) {
        
        int num1 = 1 , num2 = 2;
        
        System.out.println("La variable num1 contene el valor " + num1 + " y la variable num2 contiene el valor " + num2);
        num1++;
        num2--;
        System.out.println("Ahora, la variable num1 contiene el valor " + num1 + " y la variale num2 contiene el valor " + num2);
        
        
        
    }
    
}
