/**
 *
 * @author ALBERTO REY MORENO
 */
public class ejercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //VARIABLES DE EDAD Y ALTURA
        
        int edad=25, altura=180;
        
        //MUESTRO LOS DATOS DE NOMBRE, EDAD Y ALTURA
        
        System.out.println("Alberto Rey Moreno");
        System.out.println("Tu edad es " +edad + " años" );
        System.out.println("Tu altura es " +altura + "cm"  );
 
    }
    
}
