/**
 *
 * @author ALBERTO REY MORENO
 */

public class producto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //VARIABLES
        
        float numero1=0.5F;
        long numero2;
        float resultado;
        
        //CONSTANTES
        
        numero2=178823419991L;
        
        //PROGRAMA
        
        resultado = numero1 * numero2;
        System.out.println("El resultado de multiplicar " + numero1 + " y " + numero2 + " es igual a " + resultado);
        
    }
    
}
