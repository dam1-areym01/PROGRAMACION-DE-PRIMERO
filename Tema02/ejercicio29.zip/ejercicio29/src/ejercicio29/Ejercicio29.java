package ejercicio29;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO x8
 */
public class Ejercicio29 {

    public static void main(String[] args) {
      
        Scanner entrada = new Scanner(System.in);
        int cat1, cat2, hipotenusa;
        
        System.out.println("Por favor, introduzca el primer cateto: ");
        cat1 = entrada.nextInt();
        
        System.out.println("Por favor, introduzca el segundo cateto: ");
        cat2 = entrada.nextInt();
        
        hipotenusa = (cat1 * cat1) + (cat2 * cat2);
        System.out.println("La hipotenusa del triangulo rectácgulo es: " + hipotenusa);
        
        
    }
    
}
