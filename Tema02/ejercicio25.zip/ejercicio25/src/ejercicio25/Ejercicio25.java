package ejercicio25;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio25 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        float dat1, dat2, dat3, suma, producto;
        
        System.out.println("Por favor, introduzca el primer número: ");
        dat1 = entrada.nextFloat();
        
        System.out.println("Por favor, introduzca el segundo número: ");
        dat2 = entrada.nextFloat();
        
        System.out.println("Por favor, introduzca el tercer nçumero: ");
        dat3 = entrada.nextFloat();
        
        suma = dat1 + dat2 + dat3;
        System.out.println("La suma de los números introducido es: " + suma);
        
        producto = dat1 * dat2 * dat3;
        System.out.println("El producto de los númers introducidos es: " + producto);
        
    }
    
}
