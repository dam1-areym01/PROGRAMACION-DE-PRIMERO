package ejercicio20;
import java.util.Scanner;    
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio20 {

    public static void main(String[] args) {
        double n1;
        double n2;
        int suma;
        
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("\t Escriba el primer entero: ");
        n1 = entrada.nextDouble();
        System.out.println("\t Escriba el segundo entero: ");
        n2 = entrada.nextDouble();
        
        suma = (int) (n1 + n2);
        System.out.println("La suma de los números es: " + suma);

    }
    
}
