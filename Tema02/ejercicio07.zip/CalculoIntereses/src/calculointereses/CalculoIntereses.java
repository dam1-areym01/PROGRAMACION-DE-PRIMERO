package calculointereses;

/**
 *
 * @author ALBERTO REY MORENO
 */
public class CalculoIntereses {
    public static void main(String[] args) {
        System.out.print(2000*2.75/100/2 * (1-0.18));
    }
    
}
