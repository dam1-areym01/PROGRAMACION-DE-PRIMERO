package calculointereses2;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class CalculoIntereses2 {

    public static void main(String[] args) {
        System.out.println("Cálculo de intereses.");
        System.out.println("Dinero ingresado: 2000 €.");
        System.out.println("Interés anual: 2.75%.");
        System.out.println("Intereses a los 6 meses: " + (2000*2.75/100/2) + " €.");
        System.out.println("Retenciones realizadas: " + (2000*2.75/100/2 * 18/100) + " €.");
        System.out.println("Intereses cobrados: " + (2000*2.75/100/2 * (1 - 0.18)) + " €.");
    }
    
}
