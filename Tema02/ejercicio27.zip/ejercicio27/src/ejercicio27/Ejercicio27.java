package ejercicio27;
import java.util.Scanner;
/**
 *
 * @author ALBERTO REY MORENO
 */
public class Ejercicio27 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        int dato, doble, triple;
        
        System.out.println("Por favor, introduzca el número: ");
        dato = entrada.nextInt();
        
        doble = dato * dato;
        System.out.println("El doble de " + dato + " es " + doble);
        
        triple = dato * dato * dato;
        System.out.println("El triple de " + dato + " es " + triple);
    }
    
}
