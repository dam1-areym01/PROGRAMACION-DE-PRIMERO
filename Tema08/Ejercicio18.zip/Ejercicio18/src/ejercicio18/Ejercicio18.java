/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio18;

/**
 *
 * @author DAM1
 */
public class Ejercicio18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("=== E J E R C I C I O  B A S I C O  C A D E N A S  M U T A B L E S ===");
        
        StringBuffer cadenaMutable = new StringBuffer ("DISFRAZ");
        String mutable = "12";
        int numeroMutable = 0;
        int numeroMutable2 = 4;
        
        System.out.println("VARIABLE INICIAL: " + cadenaMutable);
        System.out.println("VARIABLE MUTABLE STRING: " + mutable);
        System.out.println("APPEND: " + cadenaMutable.append(mutable));
        System.out.println("DELETE(P1, P2): " + cadenaMutable.delete(numeroMutable, numeroMutable2));
        System.out.println("INSERT(INT POS, ELEMENTO): " + cadenaMutable.insert(numeroMutable, mutable));
        System.out.println("REPLACE(INT ORIGEN, INT FIN, STRING CADENA): " + cadenaMutable.replace(numeroMutable, numeroMutable2, mutable));
        System.out.println("LENGTH(): " + cadenaMutable.length());
        System.out.println("CAPACITY(): " + cadenaMutable.capacity());
        System.out.println("TOSTRING(): " + cadenaMutable.toString());
        
        
        
    }
    
}
