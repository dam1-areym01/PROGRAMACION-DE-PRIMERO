/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio19;

import java.util.StringTokenizer;

/**
 *
 * @author DAM1
 */
public class Ejercicio19 {

    public static void main(String[] args) {
        
        StringTokenizer tokens = new StringTokenizer ("samsung=apple=bq=huawei=xiaomi=zetta=alcatel=motorola=nokia","=");
        
        
        while (tokens.hasMoreElements()){
            System.out.println("Marca de movil: " + tokens.nextToken());
        }
        
        
    }
    
}
