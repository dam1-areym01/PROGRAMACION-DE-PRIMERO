/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio16;

import java.util.Scanner;

/**
 *
 * @author DAM1
 */
public class Ejercicio16 {

    public static String pedirArchivo() {

        Scanner entrada = new Scanner(System.in);
        System.out.println("Escriba el archivo a examinar:");
        return entrada.nextLine();

    }

    public static void dividirComprArchivo(String archivo) {

        boolean compr1, compr2;
        
        String[] dividir = archivo.split("\\.");
        // System.out.println(dividir[0] + " " + dividir[1]);
        String part1 = dividir[0];
        String part2 = dividir[1];

        if ((part1.length() > 1) && (part1.length() < 10)) {
            compr1 = true;
        } else {
            compr1 = false;
        }
        
        if ((part2.length() > 1) && (part2.length() < 4)) {
            compr2 = true;
        } else {
            compr2 = false;
        }

        if (compr1 == true && compr2 == true) {
            System.out.println("ES CORRECTO!");
        } else {
            System.out.println("ES INCORRECTO!");
        }
        
    }

    public static void main(String[] args) {

        String archivo = pedirArchivo();

        dividirComprArchivo(archivo);
    }

}
